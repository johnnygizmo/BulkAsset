import bpy
import os
from .utilities import *


class AssetRenameOperator(bpy.types.Operator):
    """Bulk Rename"""
    bl_idname = "asset.bulk_rename"
    bl_label = "Bulk Rename"
    bl_options = {'REGISTER'}

    text: bpy.props.StringProperty(name="Text")
    mode: bpy.props.EnumProperty(items=[("PREFIX", "Prefix", "Add a Prefix", 0),
                                        ("SUFFIX", "Suffix", "Add a Suffix", 1),
                                        ("RENAME", "Rename", "Rename", 2),],
                                 default="RENAME")

    commands = {}
    command_count = 0
    _timer = None

    @classmethod
    def poll(cls, context):
        return context.space_data.type == 'FILE_BROWSER' and context.space_data.browse_mode == 'ASSETS'

    def modal(self, context, event: bpy.types.Event):
        return handleModal(self, context, event)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        self.main(context)
        return finalizeExecute(self, context)

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        return {'FINISHED'}

    def main(self, context):
        directory = get_catalog_directory(context)
        for f in bpy.context.selected_asset_files:
            if f.local_id == None:
                path = get_file_path(f.relative_path, directory)
                type_out = id_type_to_type_name(f.id_type)
                if path not in self.commands.keys():
                    self.commands[path] = []
                if (self.mode == "PREFIX"):
                    self.commands[path].append(
                        "bpy.data."+type_out+"['"+f.name+"'].name =\'"+self.text+"\'+bpy.data."+type_out+"['"+f.name+"'].name;")
                elif (self.mode == "SUFFIX"):
                    self.commands[path].append(
                        "bpy.data."+type_out+"['"+f.name+"'].name =bpy.data."+type_out+"['"+f.name+"'].name+\'"+self.text+"\';")
                elif (self.mode == "RENAME"):
                    self.commands[path].append(
                        "bpy.data."+type_out+"['"+f.name+"'].name =\'"+self.text+"\';")

            else:
                if (self.mode == "PREFIX"):
                    f.local_id.name = self.text+f.local_id.name
                elif (self.mode == "SUFFIX"):
                    f.local_id.name = f.local_id.name+self.text
                elif (self.mode == "RENAME"):
                    f.local_id.name = self.text


def rename_menu_func(self, context):
    self.layout.operator(AssetRenameOperator.bl_idname,
                         text=AssetRenameOperator.bl_label)
